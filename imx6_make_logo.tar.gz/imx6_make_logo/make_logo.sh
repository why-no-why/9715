#!/bin/bash
file=$1
if [ "${file##*.}"x = "png"x ];then
    echo png
	pngtopnm $1 > temp1.pnm
	pnmquant 224 temp1.pnm > temp_clut224.pnm
	pnmtoplainpnm temp_clut224.pnm > logo_linux_clut224.ppm
	rm temp1.pnm temp_clut224.pnm
fi

if [ "${file##*.}"x = "bmp"x ];then
    echo png
	bmptoppm $1 > temp1.ppm
	ppmquant 224 temp1.ppm > temp2.ppm
	pnmnoraw temp2.ppm > logo_linux_clut224.ppm
	rm temp1.ppm temp2.ppm
fi

if [ "${file##*.}"x = "jpg"x ];then
    echo jpg
	convert "$1" "temp.png"
	pngtopnm temp.png > temp1.pnm
	pnmquant 224 temp1.pnm > temp_clut224.pnm
	pnmtoplainpnm temp_clut224.pnm > logo_linux_clut224.ppm
	rm temp1.pnm temp_clut224.pnm temp.png
fi
