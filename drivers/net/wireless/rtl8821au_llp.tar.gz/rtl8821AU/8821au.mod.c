#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

MODULE_INFO(intree, "Y");

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x6ea804cd, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0xe914e41e, __VMLINUX_SYMBOL_STR(strcpy) },
	{ 0xd465a38f, __VMLINUX_SYMBOL_STR(flush_signals) },
	{ 0x11698c25, __VMLINUX_SYMBOL_STR(usb_reset_device) },
	{ 0x88bb7f0c, __VMLINUX_SYMBOL_STR(usb_put_dev) },
	{ 0x47939e0d, __VMLINUX_SYMBOL_STR(__tasklet_hi_schedule) },
	{ 0xfa2bcf10, __VMLINUX_SYMBOL_STR(init_timer_key) },
	{ 0x5ecf23c, __VMLINUX_SYMBOL_STR(skb_queue_tail) },
	{ 0x518d019c, __VMLINUX_SYMBOL_STR(wake_up_process) },
	{ 0x47c8baf4, __VMLINUX_SYMBOL_STR(param_ops_uint) },
	{ 0x2196324, __VMLINUX_SYMBOL_STR(__aeabi_idiv) },
	{ 0xac5077a8, __VMLINUX_SYMBOL_STR(filp_open) },
	{ 0x5ca32d8f, __VMLINUX_SYMBOL_STR(register_netdev) },
	{ 0x5d41c87c, __VMLINUX_SYMBOL_STR(param_ops_charp) },
	{ 0x51c19c95, __VMLINUX_SYMBOL_STR(usb_alloc_urb) },
	{ 0x349cba85, __VMLINUX_SYMBOL_STR(strchr) },
	{ 0x699c94ab, __VMLINUX_SYMBOL_STR(unregister_netdev) },
	{ 0x9a1dfd65, __VMLINUX_SYMBOL_STR(strpbrk) },
	{ 0x82072614, __VMLINUX_SYMBOL_STR(tasklet_kill) },
	{ 0x5fc56a46, __VMLINUX_SYMBOL_STR(_raw_spin_unlock) },
	{        0, __VMLINUX_SYMBOL_STR(filp_close) },
	{ 0x37a0cba, __VMLINUX_SYMBOL_STR(kfree) },
	{ 0xfa2a45e, __VMLINUX_SYMBOL_STR(__memzero) },
	{ 0x20c2a5c2, __VMLINUX_SYMBOL_STR(__netif_schedule) },
	{ 0xe2d5255a, __VMLINUX_SYMBOL_STR(strcmp) },
	{ 0x1e6d26a8, __VMLINUX_SYMBOL_STR(strstr) },
	{ 0x8d522714, __VMLINUX_SYMBOL_STR(__rcu_read_lock) },
	{ 0x6d15fbc1, __VMLINUX_SYMBOL_STR(skb_dequeue) },
	{ 0x4e830a3e, __VMLINUX_SYMBOL_STR(strnicmp) },
	{ 0xfbc74f64, __VMLINUX_SYMBOL_STR(__copy_from_user) },
	{ 0x20000329, __VMLINUX_SYMBOL_STR(simple_strtoul) },
	{ 0x5e238409, __VMLINUX_SYMBOL_STR(unregister_netdevice_queue) },
	{ 0xf9a482f9, __VMLINUX_SYMBOL_STR(msleep) },
	{ 0x59e5070d, __VMLINUX_SYMBOL_STR(__do_div64) },
	{ 0xb8e81677, __VMLINUX_SYMBOL_STR(__dev_kfree_skb_any) },
	{ 0x2469810f, __VMLINUX_SYMBOL_STR(__rcu_read_unlock) },
	{ 0xff178f6, __VMLINUX_SYMBOL_STR(__aeabi_idivmod) },
	{ 0x2d3385d3, __VMLINUX_SYMBOL_STR(system_wq) },
	{ 0x9494d8a6, __VMLINUX_SYMBOL_STR(dev_get_drvdata) },
	{ 0xa1d55e90, __VMLINUX_SYMBOL_STR(_raw_spin_lock_bh) },
	{ 0x9c956a0f, __VMLINUX_SYMBOL_STR(seq_printf) },
	{ 0x91715312, __VMLINUX_SYMBOL_STR(sprintf) },
	{ 0x676bbc0f, __VMLINUX_SYMBOL_STR(_set_bit) },
	{ 0x4fdcbd6a, __VMLINUX_SYMBOL_STR(usb_register_driver) },
	{ 0x2153761c, __VMLINUX_SYMBOL_STR(usb_submit_urb) },
	{ 0xd62c833f, __VMLINUX_SYMBOL_STR(schedule_timeout) },
	{ 0x71c90087, __VMLINUX_SYMBOL_STR(memcmp) },
	{ 0xdcc3ea0d, __VMLINUX_SYMBOL_STR(alloc_etherdev_mqs) },
	{ 0xa9d9b9ad, __VMLINUX_SYMBOL_STR(proc_get_parent_data) },
	{ 0xa4cdf8de, __VMLINUX_SYMBOL_STR(kill_pid) },
	{ 0x3ad326b5, __VMLINUX_SYMBOL_STR(wireless_send_event) },
	{ 0x598542b2, __VMLINUX_SYMBOL_STR(_raw_spin_lock_irqsave) },
	{ 0xaad8122b, __VMLINUX_SYMBOL_STR(skb_clone) },
	{ 0xe34b6f20, __VMLINUX_SYMBOL_STR(usb_alloc_coherent) },
	{ 0x4205ad24, __VMLINUX_SYMBOL_STR(cancel_work_sync) },
	{ 0xf890557, __VMLINUX_SYMBOL_STR(kthread_create_on_node) },
	{ 0xdf5bee20, __VMLINUX_SYMBOL_STR(dev_set_drvdata) },
	{ 0xfc9c0e6b, __VMLINUX_SYMBOL_STR(skb_copy_bits) },
	{ 0x5f754e5a, __VMLINUX_SYMBOL_STR(memset) },
	{ 0x1afae5e7, __VMLINUX_SYMBOL_STR(down_interruptible) },
	{ 0x4d91af45, __VMLINUX_SYMBOL_STR(netif_rx) },
	{ 0xca54fee, __VMLINUX_SYMBOL_STR(_test_and_set_bit) },
	{ 0x9f4acac4, __VMLINUX_SYMBOL_STR(dev_get_by_name) },
	{ 0x3dfa266b, __VMLINUX_SYMBOL_STR(dev_alloc_name) },
	{ 0xf71d7295, __VMLINUX_SYMBOL_STR(skb_copy) },
	{ 0xe113bbbc, __VMLINUX_SYMBOL_STR(csum_partial) },
	{ 0x2fc63cd9, __VMLINUX_SYMBOL_STR(usb_kill_urb) },
	{ 0xd79b5a02, __VMLINUX_SYMBOL_STR(allow_signal) },
	{ 0x3bd1b1f6, __VMLINUX_SYMBOL_STR(msecs_to_jiffies) },
	{ 0x328a05f1, __VMLINUX_SYMBOL_STR(strncpy) },
	{ 0xceb3394, __VMLINUX_SYMBOL_STR(device_init_wakeup) },
	{ 0x20c55ae0, __VMLINUX_SYMBOL_STR(sscanf) },
	{ 0x5552ec54, __VMLINUX_SYMBOL_STR(netif_carrier_on) },
	{ 0x9545af6d, __VMLINUX_SYMBOL_STR(tasklet_init) },
	{ 0xd6ee688f, __VMLINUX_SYMBOL_STR(vmalloc) },
	{ 0x4be7fb63, __VMLINUX_SYMBOL_STR(up) },
	{ 0xb6b46a7c, __VMLINUX_SYMBOL_STR(param_ops_int) },
	{ 0xd7b65e2c, __VMLINUX_SYMBOL_STR(usb_control_msg) },
	{ 0x999e8297, __VMLINUX_SYMBOL_STR(vfree) },
	{ 0xa48f013b, __VMLINUX_SYMBOL_STR(netif_device_attach) },
	{ 0x9c0bd51f, __VMLINUX_SYMBOL_STR(_raw_spin_lock) },
	{ 0x7e9efe8e, __VMLINUX_SYMBOL_STR(complete_and_exit) },
	{ 0x6f0036d9, __VMLINUX_SYMBOL_STR(del_timer_sync) },
	{ 0xd4669fad, __VMLINUX_SYMBOL_STR(complete) },
	{ 0x51d559d1, __VMLINUX_SYMBOL_STR(_raw_spin_unlock_irqrestore) },
	{ 0xb2d48a2e, __VMLINUX_SYMBOL_STR(queue_work_on) },
	{ 0xdd3916ac, __VMLINUX_SYMBOL_STR(_raw_spin_unlock_bh) },
	{ 0xf7802486, __VMLINUX_SYMBOL_STR(__aeabi_uidivmod) },
	{ 0x85df9b6c, __VMLINUX_SYMBOL_STR(strsep) },
	{ 0x99bb8806, __VMLINUX_SYMBOL_STR(memmove) },
	{ 0xd513d3d0, __VMLINUX_SYMBOL_STR(find_vpid) },
	{ 0xb01ca0da, __VMLINUX_SYMBOL_STR(usb_autopm_put_interface) },
	{ 0x58c801de, __VMLINUX_SYMBOL_STR(init_net) },
	{ 0x12ab71f5, __VMLINUX_SYMBOL_STR(skb_put) },
	{ 0x63d62ea9, __VMLINUX_SYMBOL_STR(seq_lseek) },
	{ 0x275ef902, __VMLINUX_SYMBOL_STR(__init_waitqueue_head) },
	{ 0x7cf9099, __VMLINUX_SYMBOL_STR(wait_for_completion_timeout) },
	{ 0xc8fd727e, __VMLINUX_SYMBOL_STR(mod_timer) },
	{ 0xe3a3a356, __VMLINUX_SYMBOL_STR(netif_carrier_off) },
	{ 0x629f11d4, __VMLINUX_SYMBOL_STR(proc_create_data) },
	{ 0xb3a38fb1, __VMLINUX_SYMBOL_STR(usb_deregister) },
	{ 0xe707d823, __VMLINUX_SYMBOL_STR(__aeabi_uidiv) },
	{ 0x6f6c58, __VMLINUX_SYMBOL_STR(usb_free_coherent) },
	{ 0x8e865d3c, __VMLINUX_SYMBOL_STR(arm_delay_ops) },
	{ 0x7d11c268, __VMLINUX_SYMBOL_STR(jiffies) },
	{ 0xe798a258, __VMLINUX_SYMBOL_STR(single_release) },
	{ 0x725a2164, __VMLINUX_SYMBOL_STR(usb_get_dev) },
	{ 0xb81960ca, __VMLINUX_SYMBOL_STR(snprintf) },
	{ 0x394ccd97, __VMLINUX_SYMBOL_STR(PDE_DATA) },
	{ 0x75ba6c4b, __VMLINUX_SYMBOL_STR(usb_free_urb) },
	{ 0x67c2fa54, __VMLINUX_SYMBOL_STR(__copy_to_user) },
	{ 0x12da5bb2, __VMLINUX_SYMBOL_STR(__kmalloc) },
	{ 0x1af9a803, __VMLINUX_SYMBOL_STR(__netdev_alloc_skb) },
	{ 0x84c45a1e, __VMLINUX_SYMBOL_STR(register_netdevice) },
	{ 0x97255bdf, __VMLINUX_SYMBOL_STR(strlen) },
	{ 0x10b45503, __VMLINUX_SYMBOL_STR(__mutex_init) },
	{ 0x85670f1d, __VMLINUX_SYMBOL_STR(rtnl_is_locked) },
	{ 0x9fe9f047, __VMLINUX_SYMBOL_STR(__pskb_pull_tail) },
	{ 0x12a38747, __VMLINUX_SYMBOL_STR(usleep_range) },
	{ 0x6a934c5a, __VMLINUX_SYMBOL_STR(free_netdev) },
	{ 0x2d39070d, __VMLINUX_SYMBOL_STR(skb_push) },
	{ 0x2e5810c6, __VMLINUX_SYMBOL_STR(__aeabi_unwind_cpp_pr1) },
	{ 0x44da5d0f, __VMLINUX_SYMBOL_STR(__csum_ipv6_magic) },
	{ 0xe04598ad, __VMLINUX_SYMBOL_STR(remove_proc_entry) },
	{ 0x84b183ae, __VMLINUX_SYMBOL_STR(strncmp) },
	{ 0x9f984513, __VMLINUX_SYMBOL_STR(strrchr) },
	{ 0x1e22faa4, __VMLINUX_SYMBOL_STR(seq_read) },
	{ 0x3e8951de, __VMLINUX_SYMBOL_STR(skb_trim) },
	{ 0xd69e83c0, __VMLINUX_SYMBOL_STR(usb_autopm_get_interface) },
	{ 0x2a3aa678, __VMLINUX_SYMBOL_STR(_test_and_clear_bit) },
	{ 0xd2da1048, __VMLINUX_SYMBOL_STR(register_netdevice_notifier) },
	{ 0x9d0d6206, __VMLINUX_SYMBOL_STR(unregister_netdevice_notifier) },
	{ 0x17d406dd, __VMLINUX_SYMBOL_STR(proc_mkdir_data) },
	{ 0x9d669763, __VMLINUX_SYMBOL_STR(memcpy) },
	{ 0x21665d12, __VMLINUX_SYMBOL_STR(mutex_lock_interruptible) },
	{ 0xfaef0ed, __VMLINUX_SYMBOL_STR(__tasklet_schedule) },
	{ 0xf4b1916d, __VMLINUX_SYMBOL_STR(skb_pull) },
	{ 0x760a0f4f, __VMLINUX_SYMBOL_STR(yield) },
	{ 0x16305289, __VMLINUX_SYMBOL_STR(warn_slowpath_null) },
	{ 0xf6b7c0b7, __VMLINUX_SYMBOL_STR(eth_type_trans) },
	{ 0xa0b061f1, __VMLINUX_SYMBOL_STR(mutex_unlock) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0xa75c632b, __VMLINUX_SYMBOL_STR(single_open) },
	{ 0xefd6cf06, __VMLINUX_SYMBOL_STR(__aeabi_unwind_cpp_pr0) },
	{ 0xa735db59, __VMLINUX_SYMBOL_STR(prandom_u32) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

MODULE_ALIAS("usb:v0BDAp0811d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDAp0821d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDAp8822d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDApA811d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDAp0820d*dc*dsc*dp*icFFiscFFipFFin*");
MODULE_ALIAS("usb:v0BDAp0823d*dc*dsc*dp*icFFiscFFipFFin*");
MODULE_ALIAS("usb:v7392pA811d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v04BBp0953d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2001p3314d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2001p3318d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0E66p0023d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v056Ep400Ed*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v056Ep400Fd*dc*dsc*dp*ic*isc*ip*in*");

MODULE_INFO(srcversion, "8FD15D951DC745ECE0A3D31");
